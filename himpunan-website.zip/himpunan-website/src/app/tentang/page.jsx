import { Target, Eye } from 'lucide-react';

export const metadata = {
  title: 'Tentang Kami | Himpunan Mahasiswa',
};

// ISR: konten statis, cache lebih lama karena jarang berubah
export const revalidate = 3600;

const MISI_LIST = [
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor.',
  'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.',
  'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
  'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.',
];

export default function TentangPage() {
  return (
    <div>
      {/* HEADER */}
      <section className="bg-[#0F172A] py-16 lg:py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
            Tentang Kami
          </span>
          <h1 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
            Mengenal Lebih Dekat Himpunan Mahasiswa
          </h1>
        </div>
      </section>

      {/* SEJARAH */}
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <span className="text-xs font-semibold uppercase tracking-wider text-[#1E3A8A]">
          Sejarah & Latar Belakang
        </span>
        <h2 className="mt-2 text-2xl font-bold text-[#0F172A] sm:text-3xl">Perjalanan Kami</h2>
        <div className="mt-5 space-y-4 text-sm leading-relaxed text-slate-600 sm:text-base">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
            exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </p>
          <p>
            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
            fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
            qui officia deserunt mollit anim id est laborum.
          </p>
          <p>
            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
            doloremque laudantium, totam rem aperiam eaque ipsa quae ab illo inventore.
          </p>
        </div>
      </section>

      {/* VISI MISI */}
      <section className="bg-white py-16 lg:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="mb-10 text-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#1E3A8A]">
              Arah & Tujuan
            </span>
            <h2 className="mt-2 text-2xl font-bold text-[#0F172A] sm:text-3xl">Visi & Misi</h2>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Visi Card */}
            <div className="rounded-xl border border-slate-100 bg-[#F8FAFC] p-8 shadow-sm">
              <div className="mb-5 inline-flex rounded-xl bg-[#0F172A] p-3">
                <Eye className="h-6 w-6 text-white" />
              </div>
              <h3 className="mb-3 text-lg font-bold text-[#0F172A]">Visi</h3>
              <p className="text-sm leading-relaxed text-slate-600 sm:text-base">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor
                incididunt ut labore et dolore magna aliqua.
              </p>
            </div>

            {/* Misi Card */}
            <div className="rounded-xl border border-slate-100 bg-[#F8FAFC] p-8 shadow-sm">
              <div className="mb-5 inline-flex rounded-xl bg-[#0F172A] p-3">
                <Target className="h-6 w-6 text-white" />
              </div>
              <h3 className="mb-4 text-lg font-bold text-[#0F172A]">Misi</h3>
              <ul className="space-y-3">
                {MISI_LIST.map((misi, idx) => (
                  <li key={idx} className="flex gap-3 text-sm leading-relaxed text-slate-600 sm:text-base">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#1E3A8A]" />
                    {misi}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
